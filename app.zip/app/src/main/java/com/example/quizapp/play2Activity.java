package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class play2Activity extends AppCompatActivity {
    String[] question_list = {"10 + 10 = " , "7 - 6 = ","4 * 5 =","12 / 6 = ","9-5 =","12 + 6 =","2 * 2 = ","4 - 1 =","6 / 2 =","12 + 12 ="};
    String[] choose_list = {"20","2","25","17","5","1","2","25","2","22","20","25","25","2","3","22","2","25","4","5","20","49","19","18","24","20","4","1","3",
            "49","1","30","3","49","18","38","24","49","1","3","24"};
    String[] correct_list = {"20","1","20","2","4","18","4","3","3","24"};


    TextView cpt_question2 , text_question2,timer;
    Button btn_choose12 , btn_choose22 , btn_choose32 , btn_choose42 , btn_next2;

    int currentQuestion =  0  ;
    public int scorePlayer =  0  ;
    boolean isclickBtn = false;
    String valueChoose = "";
    Button btn_click;
    CountDownTimer countDownTimer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play2);
        cpt_question2 = findViewById(R.id.cpt_question2);
        text_question2 = findViewById(R.id.text_question2);
        btn_choose12 = findViewById(R.id.btn_choose12);
        btn_choose22 = findViewById(R.id.btn_choose22);
        btn_choose32 = findViewById(R.id.btn_choose32);
        btn_choose42 = findViewById(R.id.btn_choose42);
        btn_next2 = findViewById(R.id.btn_next2);
        timer=findViewById(R.id.timer2);
        startTimer();



        findViewById(R.id.image_back2).setOnClickListener(
                a-> finish()
        );
       Data();
        btn_next2.setOnClickListener(

                view -> {
                    countDownTimer.cancel();
                    if (isclickBtn){
                        isclickBtn = false;

                        if(!valueChoose.equals(correct_list[currentQuestion])){
                            Toast.makeText(play2Activity.this , "wrong answer",Toast.LENGTH_LONG).show();
                            btn_click.setBackgroundResource(R.drawable.background_btn_erreur);

                        }else {
                            Toast.makeText(play2Activity.this , "correct",Toast.LENGTH_LONG).show();
                            btn_click.setBackgroundResource(R.drawable.background_btn_correct);
                            scorePlayer++;
                            //Toast.makeText(this,String.valueOf(scorePlayer),Toast.LENGTH_SHORT).show();
                        }
                        new Handler().postDelayed(() -> {
                            if(currentQuestion!=question_list.length-1){
                                currentQuestion = currentQuestion + 1;
                               Data();
                                valueChoose = "";
                                btn_choose12.setBackgroundResource(R.drawable.background_btn_choose);
                                btn_choose22.setBackgroundResource(R.drawable.background_btn_choose);
                                btn_choose32.setBackgroundResource(R.drawable.background_btn_choose);
                                btn_choose42.setBackgroundResource(R.drawable.background_btn_choose);
                                startTimer();

                            }else {
                                Intent intent  = new Intent(play2Activity.this , ResulteActivity.class);
                                intent.putExtra("Result" , scorePlayer);
                                startActivity(intent);
                                finish();
                            }

                        },1000);

                    }else {
                        Toast.makeText(play2Activity.this ,  "please select a one answer",Toast.LENGTH_LONG).show();
                    }
                }
        );


    }
    void startTimer() {
        countDownTimer = new CountDownTimer(21000, 1000) {
            public void onTick(long millisUntilFinished) {
                // Used for formatting digit to be in 2 digits only
                NumberFormat f = new DecimalFormat("00");
                long sec = (millisUntilFinished / 1000);
                timer.setText(f.format(sec));

            }

            public void onFinish() {
                timer.setText("00");
                if (!isclickBtn) {
                    Toast.makeText(play2Activity.this, "Time's up!", Toast.LENGTH_SHORT).show();

                    if (currentQuestion != question_list.length - 1) {
                        currentQuestion = currentQuestion + 1;
                        Data();
                        valueChoose = "";
                        btn_choose12.setBackgroundResource(R.drawable.background_btn_choose);
                        btn_choose22.setBackgroundResource(R.drawable.background_btn_choose);
                        btn_choose32.setBackgroundResource(R.drawable.background_btn_choose);
                        btn_choose42.setBackgroundResource(R.drawable.background_btn_choose);

                        // Start the timer for the next question
                        startTimer();
                    }
                    else {
                        Intent intent = new Intent(play2Activity.this, ResulteActivity.class);
                        intent.putExtra("Result", scorePlayer);
                        startActivity(intent);

                    }
                }
            }
        }.start();
}


    void Data(){
        cpt_question2.setText((currentQuestion+1) + "/" + question_list.length);
        text_question2.setText(question_list[currentQuestion]);

        btn_choose12.setText(choose_list[4 * currentQuestion]);
        btn_choose22.setText(choose_list[4 * currentQuestion+1]);
        btn_choose32.setText(choose_list[4 * currentQuestion+2]);
        btn_choose42.setText(choose_list[4 * currentQuestion+3]);

    }

    public void ClickChoose(View view) {
        btn_click = (Button)view;

        if (isclickBtn) {
            btn_choose12.setBackgroundResource(R.drawable.background_btn_choose);
            btn_choose22.setBackgroundResource(R.drawable.background_btn_choose);
            btn_choose32.setBackgroundResource(R.drawable.background_btn_choose);
            btn_choose42.setBackgroundResource(R.drawable.background_btn_choose);
        }
        chooseBtn();


    }
    void chooseBtn(){

        btn_click.setBackgroundResource(R.drawable.background_btn_choose_color);
        isclickBtn = true;
        valueChoose = btn_click.getText().toString();
    }
}