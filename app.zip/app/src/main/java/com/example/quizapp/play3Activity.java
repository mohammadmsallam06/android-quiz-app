package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class play3Activity extends AppCompatActivity {
    String[] question_list = {"5 + 5 = " , "6 - 3 = ","2 * 4 =","8 / 2 = ","10-5 =","12 + 8 =","7 * 7 = ","2 - 1 =","6 / 2 =","10 + 8 ="};
    String[] choose_list = {"10","20","25","2","5","22","3","25","2","8","22","25","25","4","5","2","10","25","2","5","20","49","1","3","24","20","49","1","3",
            "7","1","3","24","49","1","3","24","12","1","18","24"};
    String[] correct_list = {"10","3","8","4","5","20","49","1","3","18"};


    TextView cpt_question3 , text_question3 , timer;
    Button btn_choose13 , btn_choose23 , btn_choose33 , btn_choose43 , btn_next3;


    int currentQuestion =  0  ;
    public int scorePlayer =  0  ;
    boolean isclickBtn = false;
    String valueChoose = "";
    Button btn_click;
    CountDownTimer countDownTimer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play3);
        cpt_question3 = findViewById(R.id.cpt_question3);
        text_question3 = findViewById(R.id.text_question3);
        btn_choose13 = findViewById(R.id.btn_choose13);
        btn_choose23 = findViewById(R.id.btn_choose23);
        btn_choose33 = findViewById(R.id.btn_choose33);
        btn_choose43 = findViewById(R.id.btn_choose43);
        btn_next3 = findViewById(R.id.btn_next3);
        timer = findViewById(R.id.timer3);
        startTimer();


        findViewById(R.id.image_back3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countDownTimer.cancel();
                finish();
            }
        });
        Data();
        btn_next3.setOnClickListener(
                view -> {
                    countDownTimer.cancel();
                    if (isclickBtn) {
                        isclickBtn = false;

                        if (!valueChoose.equals(correct_list[currentQuestion])) {
                            Toast.makeText(play3Activity.this, "wrong answer", Toast.LENGTH_LONG).show();
                            btn_click.setBackgroundResource(R.drawable.background_btn_erreur);

                        } else {
                            Toast.makeText(play3Activity.this, "correct", Toast.LENGTH_LONG).show();
                            btn_click.setBackgroundResource(R.drawable.background_btn_correct);
                            scorePlayer++;
                            //Toast.makeText(this, String.valueOf(scorePlayer), Toast.LENGTH_SHORT).show();
                        }
                        new Handler().postDelayed(() -> {
                            if (currentQuestion != question_list.length - 1) {
                                currentQuestion = currentQuestion + 1;
                                Data();
                                valueChoose = "";
                                btn_choose13.setBackgroundResource(R.drawable.background_btn_choose);
                                btn_choose23.setBackgroundResource(R.drawable.background_btn_choose);
                                btn_choose33.setBackgroundResource(R.drawable.background_btn_choose);
                                btn_choose43.setBackgroundResource(R.drawable.background_btn_choose);
                                startTimer();
                            } else {
                                Intent intent = new Intent(play3Activity.this, ResulteActivity.class);
                                intent.putExtra("Result", scorePlayer);
                                countDownTimer.cancel();
                                startActivity(intent);
                                finish();
                            }

                        }, 1000);

                    } else {
                        Toast.makeText(play3Activity.this, "please select a one answer", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
        void startTimer() {
            countDownTimer = new CountDownTimer(11000, 1000) {
                public void onTick(long millisUntilFinished) {
                    // Used for formatting digit to be in 2 digits only
                    NumberFormat f = new DecimalFormat("00");
                    long sec = (millisUntilFinished / 1000);
                    timer.setText(f.format(sec));
                }

                public void onFinish() {
                    timer.setText("00");
                    if (!isclickBtn) {
                        Toast.makeText(play3Activity.this, "Time's up!", Toast.LENGTH_SHORT).show();

                        if (currentQuestion != question_list.length - 1) {
                            currentQuestion = currentQuestion + 1;
                            Data();
                            valueChoose = "";
                            btn_choose13.setBackgroundResource(R.drawable.background_btn_choose);
                            btn_choose23.setBackgroundResource(R.drawable.background_btn_choose);
                            btn_choose33.setBackgroundResource(R.drawable.background_btn_choose);
                            btn_choose43.setBackgroundResource(R.drawable.background_btn_choose);

                            // Start the timer for the next question
                            startTimer();
                        }
                        else {
                            Intent intent = new Intent(play3Activity.this, ResulteActivity.class);
                            intent.putExtra("Result", scorePlayer);
                            startActivity(intent);

                        }
                    }
                }
            }.start();
    }

    void Data(){
        cpt_question3.setText((currentQuestion+1) + "/" + question_list.length);
        text_question3.setText(question_list[currentQuestion]);
        btn_choose13.setText(choose_list[4 * currentQuestion]);
        btn_choose23.setText(choose_list[4 * currentQuestion+1]);
        btn_choose33.setText(choose_list[4 * currentQuestion+2]);
        btn_choose43.setText(choose_list[4 * currentQuestion+3]);

    }

    public void ClickChoose(View view) {
        btn_click = (Button)view;

        if (isclickBtn) {
            btn_choose13.setBackgroundResource(R.drawable.background_btn_choose);
            btn_choose23.setBackgroundResource(R.drawable.background_btn_choose);
            btn_choose33.setBackgroundResource(R.drawable.background_btn_choose);
            btn_choose43.setBackgroundResource(R.drawable.background_btn_choose);
        }
        chooseBtn();


    }
    void chooseBtn(){

        btn_click.setBackgroundResource(R.drawable.background_btn_choose_color);
        isclickBtn = true;
        valueChoose = btn_click.getText().toString();
    }
}