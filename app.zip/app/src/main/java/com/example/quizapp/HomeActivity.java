package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.BaseMenuPresenter;

import com.example.quizapp.R;
import com.example.quizapp.play2Activity;
import com.example.quizapp.play3Activity;
import com.example.quizapp.playActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        final EditText editTextName1 = findViewById(R.id.editTextName);
        final EditText editTextAge1 = findViewById(R.id.editTextAge);
        Button btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName1.getText().toString();
                int age = Integer.parseInt(editTextAge1.getText().toString());


                Intent intent;

                if (age >= 3 && age <= 5) {
                    intent = new Intent(HomeActivity.this, playActivity.class);
                } else if (age >= 6 && age <= 8) {
                    intent = new Intent(HomeActivity.this, play2Activity.class);
                } else if (age >= 9 && age <= 11) {
                    intent = new Intent(HomeActivity.this, play3Activity.class);
                } else {
                    return;
                }


                startActivity(intent);
            }
        });


        }
    }

