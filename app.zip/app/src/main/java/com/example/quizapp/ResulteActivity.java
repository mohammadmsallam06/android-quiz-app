package com.example.quizapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;


public class ResulteActivity extends AppCompatActivity {

    TextView textView ;
    MediaPlayer mp;

    LottieAnimationView lottiesad,lottiehappy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resulte);
        textView = findViewById(R.id.textView);

        lottiesad=findViewById(R.id.animationsad);
        lottiehappy=findViewById(R.id.happy);
        int score = getIntent().getIntExtra("Result",0);
        textView.setText("Score : " + score);
        if (score>=5){
            lottiehappy.setVisibility(View.VISIBLE);
            lottiehappy.playAnimation();
            mp = MediaPlayer.create(ResulteActivity.this,R.raw.win);
        }
        else {
            mp = MediaPlayer.create(ResulteActivity.this,R.raw.lose);
            lottiesad.setVisibility(View.VISIBLE);
            lottiesad.playAnimation();

        }
        mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mp.start();
            }
        });
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                mp.release();
            }
        });

        findViewById(R.id.btn_restart).setOnClickListener(
                restart->{
                    Intent intent  = new Intent(ResulteActivity.this , MainActivity.class);
                    startActivity(intent);
                    finish();
                }
        );
    }
    public void onBackPressed() {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);

        super.onBackPressed();
    }

}